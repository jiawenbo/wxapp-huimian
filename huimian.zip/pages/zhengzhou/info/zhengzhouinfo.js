//获取应用实例
var app = getApp()
Page({
  data: {
      errorMsg:''
  },
  //页面加载监听===在此处获取newss数据
  onLoad : function (options) {
    
  }
})
